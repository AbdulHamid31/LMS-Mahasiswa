# LMS Mahasiswa dengan Prediksi Dropout

Aplikasi Streamlit untuk memantau risiko dropout mahasiswa berbasis model XGBoost dan interpretasi SHAP.